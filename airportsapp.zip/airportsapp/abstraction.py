from abc import ABC, abstractmethod


class Data(ABC):
    @abstractmethod
    def abs1(self):
        pass


class Test1(Data):
    def abs1(self):
        print("xxx")


Test1()