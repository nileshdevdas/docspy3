from abc import ABC, abstractmethod


# this is a bas abstract class with a abstract method fly decorated with @abstractmethod
class Superman(ABC):
    @abstractmethod
    def fly(self):
        pass

# COncrete implementation
class TheRealSuperman(Superman):
    def fly(self):
        print("Real SuperMan if flying")

#Contract Mandates that anyone you wishes to do x has to implement the requir method 
# it gets mandated for the person to make use of the these methods and have to implemnt thme 
