# python cannot import anything beyond its own root package
# unless that package is in your path 
# solution is 

import sys;
#sys.path.append('C:\\airportsapp')
#print(sys.path)
from ..parsers import csv_parser;
print(csv_parser.parse_csv)
