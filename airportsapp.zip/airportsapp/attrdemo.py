import attr


@attr.s
class Test:
    x = attr.ib(default=10)


print(Test().x)