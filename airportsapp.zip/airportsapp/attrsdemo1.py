import attr

@attr.s
class Users:
    x = attr.ib(default=10)
    y = attr.ib(default=20)


print(Users().x)
print(Users().y)