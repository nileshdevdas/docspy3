class bicycle:
    pass