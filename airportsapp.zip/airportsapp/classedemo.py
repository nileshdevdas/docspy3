class Loan:
    a = 10

    @staticmethod
    def static_method():
        pass

    def object_method(self):
        pass

    def __init__(self):
        self.username = "xxxxx"
        self.password = "xxxxx"
        pass

    def __del__(self):
        pass

    def __str__(self):
        return super().__str__()


print(Loan.a)


class GoldLoan(Loan):
    def __init__(self):
        pass

a = GoldLoan()
a.object_method()

