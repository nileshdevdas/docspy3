class Employee:
    pass


class Manager(Employee):
    pass

