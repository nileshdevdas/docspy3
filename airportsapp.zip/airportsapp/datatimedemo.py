import datetime
import glob


import inspect;

print(datetime.datetime.now())

date = datetime.datetime.strptime('10/10/2017', '%d/%m/%Y')
print(date.day)
print(date.month)
print(date.time)

print(inspect.getmembers(date))

print(glob.glob("c:/*.txt"))
