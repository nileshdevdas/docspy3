class Hello:
    @staticmethod
    def cherio():
        print("cherio")

    def cherio_inst(self):
        print("Cherio Inst")

Hello.cherio()
Hello().cherio_inst()
