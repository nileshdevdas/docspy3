import logging

logging.basicConfig(
    filename="d:/demo.log",
    level="ERROR",
    format=" %(asctime)s  %(name)s %(levelname)s %(funcName)s  %(lineno)d s%(message)s")

logging.debug("xxxxxxxx")
logging.info("INFO MESSAGE")
logging.error("ERROR MESSAage")
logging.warn("A Warning Message ")
