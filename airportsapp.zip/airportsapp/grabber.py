"""
 Web Grabber program Which grabs price of WK7600 From 2 websites
"""
import requests
from bs4 import BeautifulSoup


def grab_prices():
    """
        Grab Prices is priced as a pricing action
    """
    data = requests.get(
        "https://www.amazon.in/Casio-WK7600-76-Key-Workstation-Keyboard/" +
        "dp/B00GXNS5PU/ref=sr_1_1?keywords=wk+7600&qid=1570729673&sr=8-1",
        headers={
            "user-agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"
        })
    soup = BeautifulSoup(data.text, features="lxml")
    divs = soup.find("span", {"id": "priceblock_ourprice"})
    print("Amazon Price is " + divs.text)
    data2 = requests.get(
        "https://www.flipkart.com/casio-wk-7600-kh30-digital-portable-keyboard/p"
        +
        "/itmfftfwykqjgh54?pid=MKDFFTFWKVEPKGSU&lid=LSTMKDFFTFWKVEPKGSUCYXSUU&"
        +
        "marketplace=FLIPKART&srno=s_1_1&otracker=search&otracker1=search&fm="
        +
        "SEARCH&iid=994e477f-7282-4a43-b14d-164e0ee4fc95.MKDFFTFWKVEPKGSU.SEARCH"
        +
        "&ppt=sp&ppn=sp&ssid=cr6mtjttk00000001570729803620&qH=10f02e8672d027c7",
        headers={
            "user-agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36"
        })

    soup2 = BeautifulSoup(data2.text, features='lxml')
    result = soup2.find("div", {'class': '_1vC4OE _3qQ9m1'})
    print("Price at Flipkart" +   result.text)

grab_prices()


