from bicycle import bicycle;

bicycle()