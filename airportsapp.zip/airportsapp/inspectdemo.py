import inspect

users= ['a', 'b']

print(inspect.getmembers(users))