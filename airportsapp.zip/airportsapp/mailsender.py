import smtplib;


mail = smtplib.SMTP(host="mail.vinsys.com", port=587)
mail.starttls() # to start the  ssl 
mail.login('iot@vinsys.com', '1QAZxsw@');
mail.sendmail(
        msg="Hello From Python", 
        to_addrs="nilesh.devdas@outlook.com", 
        from_addr= "iot@vinsys.com"
)