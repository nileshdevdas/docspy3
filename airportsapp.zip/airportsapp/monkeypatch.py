class TestMe:
    def hello(self):
        print("hello")


def another_hello(self):
    print("Another hello")


TestMe.hello = another_hello

TestMe().hello()


