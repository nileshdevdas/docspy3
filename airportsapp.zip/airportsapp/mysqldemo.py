import mysql.connector

mysql.connector.connect()
