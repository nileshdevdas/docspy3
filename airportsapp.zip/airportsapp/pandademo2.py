import pandas as pd

df = pd.read_csv("c:/airports.csv")

airportnames = df['name']

for d in df:
    print(d)

#print(df['type'])

print(df.head())
print(df.tail())