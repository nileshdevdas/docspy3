import cProfile


def a():
    r = range(1, 100)
    for r2 in r : 
        pass


def b():
    r1 = range(1, 200)
    for rx in r1:
        a()


cProfile.run("b()")