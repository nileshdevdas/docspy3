def parse_csv(data):
    pass