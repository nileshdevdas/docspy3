

def parse_json(data):
    pass    