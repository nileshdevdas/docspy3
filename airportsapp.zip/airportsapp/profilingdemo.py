import cProfile

def a():
    r = range(1, 20000)
    for r1 in r:
        a = 10
        b = 20
        c = a + b


def b():
    r1 = range(1, 200)
    for rx in r1:
        a()


cProfile.run("b()");



