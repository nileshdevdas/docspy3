"""
desc goes here
"""


class Account:
    """
    desc goes here
    """
    def __init__(self):
        """
        desc goes here
        """
        self.username = "nilesh"
        self.password = "abcaxyz"
        print("Self is the pointer to this object ", end="")
        print(self)

    def __del__(self):
        """
        desc goes here
        """
        print("This is a function for destruction")

    def object_method(self):
        """
        desc goes here
        """
        print(
            "The self point to the object hence you are in objectorientred world "
        )
        print("It is just discipline to call it as self ")

    def __str__(self):
        """
        desc goes here
        return "This is My Account"
        """
        return "Cool Coool Cool "

    @staticmethod
    def class_method():
        """
        desc goes here
        """
        print("this is a method of the class")


# how to create a object
account = Account()
# how to call a object method
account.object_method()
# how to call a class Method
Account.class_method()
# does object have any more method
print(account)
print(account.username)
print(account.password)
# how to delete an object
del account
# how do i extend a classs


class GoldAccount(Account):
    def object_method(self):
        super().object_method()
        print("Which Object method ? ???? ")


gaccount = GoldAccount()
gaccount.object_method()
