class Account:
    def __init__(self):
        print("init was called")

    def any_method(self):
        print("This is any object level method")

    @staticmethod
    def any_class_method(self):
        print(self)
        print("Want to use this as classmethod")

    def __del__(self):
        print("Deleted ")


account = Account()
account.any_method()
# static methods can be called directly by class name.method_name
# object methods can be called directly by using instance.methodName
Account.any_class_method('xxxxx')
