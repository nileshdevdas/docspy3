import re


print(re.search("\s", "a anan sososdsdsd "))
print(re.match("regx",  "Text`"))