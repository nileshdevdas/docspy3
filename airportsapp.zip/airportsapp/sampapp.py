import sys


big_airports = []
small_airports =[]
other_airports = []

def read_file(filename):
    if filename == None:
        raise Exception("File Name Cannot be null")
    else:
        file = None
        try:
            file = open(file=filename, mode='rt', encoding='utf-8')
            line = file.readline()
            while line:
                airport = parse(line)
                filter(airport)
                line = file.readline()
        except Exception as e:
            print(e)
        finally:
            if file != None:
                file.close()


def parse(line):
    if line != None:
        newline = line.replace("\"", "")
        data = newline.split(",")
        airport = {}
        airport['name'] = data[3]
        airport['type'] = data[2]
        return airport
    else:
        print("No Data")
        return ""


def filter(airport):
    #print(airport)
    if airport['type'] == 'small_airport':
        small_airports.append(airport)
    elif airport['type'] == 'large_airport':
        big_airports.append(airport)
    else:
        other_airports.append(airport)


def dump_file():
    print("dumping fiel")


def main():
    read_file(sys.argv[1])
    parse()
    filter()
    dump_file()


if __name__ == "__main__":
    main()
