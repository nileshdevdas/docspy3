print("Welcome Mr.{0} {1}  and You id : {2} is created {3}".format("ssssWW", "xx" , "xxx", "xxx"))

def myfunc(*myargs):
    print(myargs)
myfunc(1,2,3,4,54,5,"sdsdsd", "232323")
