import pytest


# fixture is decorator and the the function can be injected and passed to whatever test
# you wish to use use it with
@pytest.fixture
def users_data():
    return ['nilesh', 'xxxxxx', 'xxxxx']

def test_create_users(users_data):
    assert users_data[0] == 'nilesh1'

def test_test2():
    assert True

def test_test3():
    assert True
