### Python support object orientation
### python support classes 
#### python support __init__ (constructors )
##  pytho support __del__ as destructors
##  python classes do have other method __str__ , __eq__
##  all Classes finall extend object 
##  Classes can have Inheritence 
## classe can have static methods 
##  object methods 
##  overriding 
##  this allows me to create object ()  and deleting a del <obj> 
##  classes can be abstract provided the extend (ABC) and use @abstactmethod 
##  classes can have static members of vairables 
##  object variable  self.xxxxx 
##  the self is not a mandaotry name can be anything but design discipline for python says it should self 
##  No mandate on classes having  any special filename or class name 
##  classes  are  used generally for state and behavoir modelling and unless you dont have a  a reason that 
#   functions dont work you can define classes 
### Memory Management of classes and objects is to be done by the programmer there is not direct / indirect 
###  gc / cleanup or any type memory management seperate in python 




from abc import ABC, abstractmethod


class AnyClass(ABC):
    @abstractmethod
    def any_method_you_want_to_make_abstract(self):
        pass




class May_Be_A_Concrete_Class(AnyClass):
    def any_method_you_want_to_make_abstract(self):
        pass


May_Be_A_Concrete_Class()
