def check_null(data):
    pass