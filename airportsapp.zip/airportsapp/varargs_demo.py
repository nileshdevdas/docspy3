def a(*args, **args2):
    print(args2)
    print(args)


a(1, 2, 3, 4, 5)


class A:
    def t1(self):
        print("t1")


A.t1 = lambda self: print('T2')

A().t1()

a = [[1, 3, 4], [2]]
print(a[0][1])
